﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Customers
    {
        [Key]
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
        public string MailID { get; set; }
        public string MobileNumber { get; set; }
    }
}
