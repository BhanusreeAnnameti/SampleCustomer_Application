﻿using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using WebApplication1.Models;

namespace WebApplication1.DataLayer
{
    public class CustomerDAL
    {
        public string cnn = "";
        public CustomerDAL()
        {
            var builder = new ConfigurationBuilder().SetBasePath
                (Directory.GetCurrentDirectory()).
                AddJsonFile("appsettings.json")
                .AddUserSecrets<Program>().Build();
            cnn = builder.GetSection("ConnectionStrings:LocalDB").Value;
        }
        public List<Customers> GetAllCustomers()
        {
            List<Customers> ListOfCustomers = new List<Customers>();
            using (SqlConnection cn = new SqlConnection(cnn))
            {
                using (SqlCommand cmd = new SqlCommand("GetAllCustomers", cn))
                {
                    if (cn.State == ConnectionState.Closed)
                        cn.Open();
                    IDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        ListOfCustomers.Add(new Customers()
                        {
                            CustomerID = int.Parse(reader["CustomerID"].ToString()),
                            CustomerName = reader["CustomerName"].ToString(),
                            MailID = reader["MailID"].ToString(),
                            MobileNumber = reader["MobileNumber"].ToString(),
                        });
                    }
                }
            }
            return ListOfCustomers;
        }


        public List<Customers> GetCustomersByID(int CustomerID)
        {
            List<Customers> ListOfCustomers = new List<Customers>();
            using (SqlConnection cn = new SqlConnection(cnn))
            {
                using (SqlCommand cmd = new SqlCommand("GetCustomerDetailsByID", cn))
                {
                    cmd.Parameters.Add("@CustomerID", SqlDbType.Int);
                    cmd.Parameters["@CustomerID"].Value = CustomerID;
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (cn.State == ConnectionState.Closed)
                        cn.Open();
                    IDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        ListOfCustomers.Add(new Customers()
                        {
                            CustomerID = int.Parse(reader["CustomerID"].ToString()),
                            CustomerName = reader["CustomerName"].ToString(),
                            MailID = reader["MailID"].ToString(),
                            MobileNumber = reader["MobileNumber"].ToString(),
                        });
                    }
                }
            }
            return ListOfCustomers;
        }
    }
}
